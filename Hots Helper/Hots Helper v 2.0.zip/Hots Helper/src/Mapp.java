import java.util.Scanner;

public class Mapp {


    public String Mapp(){


        String mapshrines = "Infernal Shrines";
        String mapbraxis = "Braxis Holdout";
        String mapeternity = "Battlefield of Eternity";

        Reader reader = new Reader();

        System.out.println("If yor map is: " + mapbraxis + " write \"br\" , if yor map is " + mapeternity + " write \"et\" , if yor map is " + mapshrines + "write \"sh\".");
        String maps = reader.Reader();
        return maps;





    }


}
