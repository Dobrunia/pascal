import java.util.Scanner;

public class Typeofdd {
    private String typef = "";
    private int o = 0;

    public Typeofdd(){
        o = 0;
    }

    public String Result(){
        System.out.println("In team you have mage(write m) or AA(write a)?");
        Scanner sc = new Scanner(System.in);
        this.typef = sc.nextLine();
        return typef;
    }


}
