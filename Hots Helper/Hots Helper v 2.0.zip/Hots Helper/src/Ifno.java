public class Ifno {

    public String Ifno(){

        String[] aat = new String[4];
        aat[0] = "Raynor";
        aat[1] = "Fenix";
        aat[2] = "Tracer";
        aat[3] = "Ragnaros";


        String[] mages = new String[6];
        mages[0] = "Li-Ming";
        mages[1] = "Orphea";
        mages[2] = "Mephisto";
        mages[3] = "Hanzo";
        mages[4] = "Genji";
        mages[5] = "Jaina";

        Reader reader = new Reader();
        Mapp mapp = new Mapp();

        System.out.println("Ok, what damage dealer you prefer? mage(write m) or AA(write a)?");
        String z = reader.Reader();


        String df = mapp.Mapp();


        switch (z) {
            case "a":

                if (df.equalsIgnoreCase("br")){
                    int ss = (int)(Math.random() * 10);
                    if (Math.abs(ss) <= 4){
                        System.out.println("Pick " + aat[0]);
                    } else if (Math.abs(ss) > 4 && Math.abs(ss) <=7){
                        System.out.println("Pick " + aat[1]);

                    } else {
                        System.out.println("Pick " + aat[3]);
                    }
                } else if (df.equalsIgnoreCase("et")){
                    int ss = (int)(Math.random() * 10);
                    if (ss <= 5){
                        System.out.println("Pick " + aat[0]);
                    } else {
                        System.out.println("Pick " + aat[2]);
                    }
                } else if (df.equalsIgnoreCase("sh")){
                    int ss = (int)(Math.random() * 10 - aat.length);
                    if (Math.abs(ss) <= 4){
                        System.out.println("Pick " + aat[0]);
                    } else if (Math.abs(ss) > 4 && Math.abs(ss) <=7){
                        System.out.println("Pick " + aat[1]);

                    } else {
                        System.out.println("Pick " + aat[3]);
                    }
                } else {
                    System.out.println("Eror Reader(Ifno)");
                }

                break;
            case "m":
                if (df.equalsIgnoreCase("br")){
                    int w = (int)(Math.random() * 10 - 1);
                    int ss = Math.abs(w) - mages.length;
                    if (Math.abs(w) != 0 && Math.abs(w) != 2){
                        System.out.println("Pick " + mages[Math.abs(ss)]);
                    } else {
                        System.out.println("Pick " + mages[4]);
                    }
                } else if (df.equalsIgnoreCase("et")){
                    int w = (int)(Math.random() * 10 - 1);
                    int ss = Math.abs(w) - mages.length;
                    if (Math.abs(w) != 0 && Math.abs(w) != 2){
                        System.out.println("Pick " + mages[Math.abs(ss)]);
                    } else {
                        System.out.println("Pick " + mages[4]);
                    }
                } else if (df.equalsIgnoreCase("sh")){
                    int w = (int)(Math.random() * 10 - 1);
                    int ss = Math.abs(w) - mages.length;
                    if (Math.abs(ss) != 0){
                        System.out.println("Pick " + mages[Math.abs(ss)]);
                    } else {
                        System.out.println("Pick " + mages[4]);
                    }

                } else {
                    System.out.println("Eror Reader(Ifno)");
                }
                break;
            default:
                throw new IllegalArgumentException("You input sm strange, try again");


        } return "";
    }
}
