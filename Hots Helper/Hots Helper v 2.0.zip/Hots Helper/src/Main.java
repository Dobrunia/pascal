import java.io.InputStream;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        /*
        TODO: рограмма считаыает 1)есть ли уже дд (маг или авто а) 1.2)предпочтения если нет 3)карту
         */
//        String[] heroes = new String[10];
//        heroes[0] = "Ragnaros";
//        heroes[1] = "Raynor";
//        heroes[2] = "Li-Ming";
//        heroes[3] = "Orphea";
//        heroes[4] = "Mephisto";
//        heroes[5] = "Fenix";
//        heroes[6] = "Hanzo";
//        heroes[7] = "Genji";
//        heroes[8] = "Tracer";
//        heroes[9] = "Jaina";

//        String ragna = "Ragnaros";
//        String raynor = "Raynor";
//        String li = "Li-Ming";
//        String orp = "Orphea";
//        String mep = "Mephisto";
//        String fen = "Fenix";
//        String han = "Hanzo";
//        String gen = "Genji";
//        String tr = "Tracer";
//        String jai = "Jaina";
//        String mapshrines = "Infernal Shrines";
//        String mapbraxis = "Braxis Holdout";
//        String mapeternity = "Battlefield of Eternity";

        EmptySlot emptySlot = new EmptySlot();
        //Typeofdd typeofdd = new Typeofdd();
        Analizator analizator = new Analizator();
        //Mapp mapp = new Mapp();
        //Reader reader = new Reader();
        Reader reader = new Reader();
        Ifno ifno = new Ifno();

        System.out.println("Write \" yes \" if you already have dd in you team else write \" no \"");
        String es = reader.Reader();


        if (es.equalsIgnoreCase("yes")){
            //typeofdd.Result();
            //mapp.Mapp();
            analizator.Swch();

        } else if (es.equalsIgnoreCase("no")){

            ifno.Ifno();

            } else {
            System.out.println("Try again:)");
        }


//        System.out.println("If yor map is: " + mapbraxis + " write \"br\" , if yor map is " + mapeternity + " write \"et\" , if yor map is " + mapshrines + "write \"sh\".");
//
//        Scanner map = new Scanner(System.in);
//        String maps = map.nextLine();
//
//
//        switch (maps) {
//            case "br":
//                switch (emptySlot.Slot()){
//                    case "yes":
//                        //System.out.println("In team you have mage(write m) or AA(write a)?");
//
//                        break;
//                    case "no":
//                        System.out.println("Pick " + ragna);
//                        break;
//                    default:
//                        throw new IllegalArgumentException("You input sm strange, try again");
//
//                }
//                //System.out.println("Your hero: " + ragna);
////                    if (emptySlot.Slot() == "yes") {
////                        System.out.println("In team you have mage(write m) or AA(write a)?");
////                    }
////                    else {
////                        System.out.println("Pick " + ragna);
////                    }
//
//                break;
//            case "et":
//                //System.out.println("Ваш герой: " + li);
//                switch (emptySlot.Slot()) {
//                    case "yes":
//                        System.out.println("In team you have mage(write m) or AA(write a)?");
//                        break;
//                    case "no":
//                        System.out.println("Pick " + li);
//                        break;
//                    default:
//                        throw new IllegalArgumentException("You input sm strange, try again");
//                }
//
//
//                break;
//            case "sh":
//                //System.out.println("Ваш герой: " + raynor);
//                switch (emptySlot.Slot()) {
//                    case "yes":
//                        System.out.println("In team you have mage(write m) or AA(write a)?");
//                        break;
//                    case "no":
//                        System.out.println("Pick " + raynor);
//                        break;
//                    default:
//                        throw new IllegalArgumentException("You input sm strange, try again");
//                }
//                break;
//            default:
//                throw new IllegalArgumentException("You input sm strange, try again");
//        }
//        return;


    }


}
