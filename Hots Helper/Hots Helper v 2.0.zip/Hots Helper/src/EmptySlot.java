import java.util.Scanner;

public class EmptySlot {




    public String Slot(){

        Reader reader = new Reader();

        System.out.println("Write \" yes \" if you already have dd in you team else write \" no \"");
        String slots = reader.Reader();
        return slots;
    }
//
//    @Override
//    public String toString() {
//        return slots;
//    }

}
