import java.util.Scanner;

public class Reader {


    public String Reader(){
        Scanner sc = new Scanner(System.in);
        String read = sc.nextLine();
        return read;
    }
}
