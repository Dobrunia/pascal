
public class Analizator {

    public void Swch() {
        Typeofdd typeofdd = new Typeofdd();

        String[] mele = {"Tracer", "Ragnaros", "Ilidan", "Greymane", "Zeratul", "Alarak", "Varian", "Karrigan", "Malthael", "Maiev", "Butcher", "Samuro"};
        String[] range ={"Li-Ming", "Orphea", "Mephisto", "Hanzo", "Genji", "Jaina", "Valla", "Raynor", "Fenix", "Guldan", "Junkrat", "Falstad", "Cassia", "Taicus", "Lunara", "Chromie"};


        Mapp mapp = new Mapp();
        String df = mapp.Mapp();
        String res = typeofdd.Result();



        switch (res) {
            case "m":

                if (df.equalsIgnoreCase("br")){
                    int ss = (int)(Math.random() * 10);
                    if (Math.abs(ss) <= 4){
                        System.out.println("Pick " + mele[0]);
                    } else if (Math.abs(ss) > 4 && Math.abs(ss) <=7){
                        System.out.println("Pick " + mele[1]);

                    } else {
                        System.out.println("Pick " + mele[3]);
                    }
                } else if (df.equalsIgnoreCase("et")){
                    int ss = (int)(Math.random() * 10);
                    if (Math.abs(ss) <= 5){
                        System.out.println("Pick " + mele[0]);
                    } else {
                        System.out.println("Pick " + mele[2]);
                    }
                } else if (df.equalsIgnoreCase("sh")){
                    int ss = (int)(Math.random() * 10);
                    if (Math.abs(ss) <= 4){
                        System.out.println("Pick " + mele[0]);
                    } else if (Math.abs(ss) > 4 && Math.abs(ss) <=7){
                        System.out.println("Pick " + mele[1]);

                    } else {
                        System.out.println("Pick " + mele[3]);
                    }
                } else {
                    System.out.println("Eror Mapp(Analizator)");
                }

                break;
            case "a":
                if (df.equalsIgnoreCase("br")){
                    int w = (int)(Math.random() * 10 - 1);
                    int ss = Math.abs(w) - range.length;
                    if (Math.abs(w) != 0 && Math.abs(w) != 2){
                        System.out.println("Pick " + range[Math.abs(ss)]);
                    } else {
                        System.out.println("Pick " + range[4]);
                    }
                } else if (df.equalsIgnoreCase("et")){
                    int w = (int)(Math.random() * 10 - 1);
                    int ss = Math.abs(w) - range.length;
                    if (Math.abs(w) != 0 && Math.abs(w) != 2){
                        System.out.println("Pick " + range[Math.abs(ss)]);
                    } else {
                        System.out.println("Pick " + range[4]);
                    }
                } else if (df.equalsIgnoreCase("sh")){
                    int w = (int)(Math.random() * 10 - 1);
                    int ss = Math.abs(w) - range.length;
                    if (ss != 0){
                        System.out.println("Pick " + range[Math.abs(ss)]);
                    } else {
                        System.out.println("Pick " + range[4]);
                    }

                } else {
                    System.out.println("Eror Mapp(Analizator)");
                }
                break;
            default:
                throw new IllegalArgumentException("You input sm strange, try again");


        }

    }
}



