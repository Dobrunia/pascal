import java.io.InputStream;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
        TODO: рограмма считаыает 1)есть ли уже дд (маг или авто а) 1.2)предпочтения если нет 3)карту
         */
        String ragna = "Ragnaros";
        String raynor = "Raynor";
        String li = "Li-Ming";
        String mapshrines = "Infernal Shrines";
        String mapbraxis = "Braxis Holdout";
        String mapeternity = "Battlefield of Eternity";


        EmptySlot emptySlot = new EmptySlot();


        System.out.println("If yor map is: " + mapbraxis + " write \"br\" , if yor map is " + mapeternity + " write \"et\" , if yor map is " + mapshrines + "write \"sh\".");

        Scanner map = new Scanner(System.in);
        String maps = map.nextLine();


        switch (maps) {
            case "br":
                switch (emptySlot.Slot()){
                    case "yes":
                        System.out.println("In team you have mage(write m) or AA(write a)?");
                        break;
                    case "no":
                        System.out.println("Pick " + ragna);
                        break;
                    default:
                        throw new IllegalArgumentException("You input sm strange, try again");

                }
                //System.out.println("Your hero: " + ragna);
//                    if (emptySlot.Slot() == "yes") {
//                        System.out.println("In team you have mage(write m) or AA(write a)?");
//                    }
//                    else {
//                        System.out.println("Pick " + ragna);
//                    }

                break;
            case "et":
                System.out.println("Ваш герой: " + li);
                //TODO
                break;
            case "sh":
                System.out.println("Ваш герой: " + raynor);
                //TODO
                break;
            default:
                throw new IllegalArgumentException("You input sm strange, try again");
        }
        return;


    }


}
