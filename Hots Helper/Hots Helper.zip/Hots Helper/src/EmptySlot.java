import java.util.Scanner;

public class EmptySlot {
    private String slots = "";
    private int j = 0;


    public EmptySlot(){
        j = 0;
    }

    public String Slot(){
        System.out.println("Write \" yes \" if you already have dd in you team else write \" no \"");
        Scanner sc = new Scanner(System.in);
        this.slots = sc.nextLine();
        return slots;
    }
//
//    @Override
//    public String toString() {
//        return slots;
//    }

}
